import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../core/theme/app_theme.dart';
import '../providers/smartwatch_provider.dart';

class SmartWatchScreen extends ConsumerStatefulWidget {
  const SmartWatchScreen({super.key});

  @override
  ConsumerState<SmartWatchScreen> createState() => _SmartWatchScreenState();
}

class _SmartWatchScreenState extends ConsumerState<SmartWatchScreen>
    with TickerProviderStateMixin {
  late AnimationController _pulseCtrl;
  final _hostCtrl = TextEditingController(text: 'localhost');
  final _portCtrl = TextEditingController(text: '8765');

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _hostCtrl.dispose();
    _portCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = ref.watch(watchProvider);
    final notifier = ref.read(watchProvider.notifier);
    final connected = s.status == WatchStatus.connected;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── Header ────────────────────────────────────────────────
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 80, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      const Text('⌚', style: TextStyle(fontSize: 22)),
                      const SizedBox(width: 10),
                      Text('Health Metrics',
                          style: GoogleFonts.playfairDisplay(
                              fontSize: 22,
                              fontWeight: FontWeight.w700,
                              color: AppColors.plum900)),
                    ]),
                    const SizedBox(height: 2),
                    Text(
                      connected ? 'Live · Syncing every second' : 'Connect to get started',
                      style: AppTextStyles.caption.copyWith(
                          color: connected ? AppColors.sage600 : AppColors.neutral400),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // ── Main connect card ──────────────────────────────────────
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: connected
                    ? _ConnectedCard(s: s, pulseCtrl: _pulseCtrl)
                    : _ConnectCard(
                        status: s.status,
                        errorMessage: s.errorMessage,
                        hostCtrl: _hostCtrl,
                        portCtrl: _portCtrl,
                        onConnect: () => notifier.connect(
                          host: _hostCtrl.text.trim(),
                          port: int.tryParse(_portCtrl.text.trim()) ?? 8765,
                        ),
                      ),
              ),

              // ── Live metrics grid (only when connected) ────────────────
              if (connected && s.metrics != null) ...[
                const SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: _MetricsGrid(s: s),
                ),

                // Heart rate chart
                if (s.heartRateHistory.length > 1) ...[
                  const SizedBox(height: 16),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: _HrChart(history: s.heartRateHistory),
                  ),
                ],

                // Auto-sync + disconnect
                const SizedBox(height: 16),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(children: [
                    Expanded(
                      child: _SyncTile(
                        autoSync: s.autoSync,
                        onToggle: notifier.toggleAutoSync,
                      ),
                    ),
                    const SizedBox(width: 10),
                    GestureDetector(
                      onTap: notifier.disconnect,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 18, vertical: 14),
                        decoration: BoxDecoration(
                          color: AppColors.rose50,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: AppColors.rose200),
                        ),
                        child: Text('Disconnect',
                            style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: AppColors.rose700)),
                      ),
                    ),
                  ]),
                ),
              ],

              const SizedBox(height: 100),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Connect Card (not yet paired — matches the screenshot exactly) ───────────

class _ConnectCard extends StatefulWidget {
  final WatchStatus status;
  final String? errorMessage;
  final TextEditingController hostCtrl;
  final TextEditingController portCtrl;
  final VoidCallback onConnect;

  const _ConnectCard({
    required this.status,
    required this.errorMessage,
    required this.hostCtrl,
    required this.portCtrl,
    required this.onConnect,
  });

  @override
  State<_ConnectCard> createState() => _ConnectCardState();
}

class _ConnectCardState extends State<_ConnectCard> {
  bool _showAdvanced = false;

  @override
  Widget build(BuildContext context) {
    final connecting = widget.status == WatchStatus.connecting;

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF2D1B4E), Color(0xFF1A0F2E)],
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF2D1B4E).withOpacity(0.4),
            blurRadius: 32,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Column(
        children: [
          // ── Watch illustration ───────────────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 36, 24, 0),
            child: Column(
              children: [
                // Watch icon
                Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.08),
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: Colors.white.withOpacity(0.15), width: 1.5),
                  ),
                  alignment: Alignment.center,
                  child: connecting
                      ? const SizedBox(
                          width: 36,
                          height: 36,
                          child: CircularProgressIndicator(
                              color: Colors.white, strokeWidth: 2.5),
                        )
                      : const Text('⌚', style: TextStyle(fontSize: 42)),
                ).animate().fadeIn(duration: 400.ms).scaleXY(begin: 0.8),

                const SizedBox(height: 24),

                // Title
                Text(
                  'Connect Health Data',
                  style: GoogleFonts.playfairDisplay(
                    fontSize: 22,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                  textAlign: TextAlign.center,
                ),

                const SizedBox(height: 10),

                // Subtitle
                Text(
                  'Pull heart rate, blood pressure, SpO₂, steps, '
                  'sleep, and more from your wearable device.',
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.white.withOpacity(0.6),
                    height: 1.5,
                  ),
                  textAlign: TextAlign.center,
                ),

                const SizedBox(height: 28),

                // ── Connect button ─────────────────────────────────────
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: connecting ? null : widget.onConnect,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.white,
                      side:
                          const BorderSide(color: Colors.white60, width: 1.5),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    child: connecting
                        ? Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const SizedBox(
                                  width: 16,
                                  height: 16,
                                  child: CircularProgressIndicator(
                                      color: Colors.white, strokeWidth: 2)),
                              const SizedBox(width: 10),
                              const Text('Connecting…',
                                  style: TextStyle(fontSize: 13)),
                            ],
                          )
                        : const Text('Connect Health & Fitness',
                            style: TextStyle(
                                fontSize: 13, fontWeight: FontWeight.w600)),
                  ),
                ),

                const SizedBox(height: 14),

                // ── Error ────────────────────────────────────────────────
                if (widget.errorMessage != null)
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.red.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.red.withOpacity(0.3)),
                    ),
                    child: Text(widget.errorMessage!,
                        style: const TextStyle(
                            fontSize: 11, color: Colors.redAccent),
                        textAlign: TextAlign.center),
                  ),

                const SizedBox(height: 16),

                // ── Advanced settings toggle ──────────────────────────────
                GestureDetector(
                  onTap: () =>
                      setState(() => _showAdvanced = !_showAdvanced),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        _showAdvanced
                            ? Icons.expand_less_rounded
                            : Icons.tune_rounded,
                        color: Colors.white38,
                        size: 14,
                      ),
                      const SizedBox(width: 4),
                      Text('Simulator settings',
                          style: TextStyle(
                              fontSize: 11, color: Colors.white38)),
                    ],
                  ),
                ),

                AnimatedSize(
                  duration: const Duration(milliseconds: 250),
                  child: _showAdvanced
                      ? Padding(
                          padding: const EdgeInsets.only(top: 12),
                          child: Row(
                            children: [
                              Expanded(
                                flex: 3,
                                child: _DarkTextField(
                                    ctrl: widget.hostCtrl, label: 'Host'),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                flex: 1,
                                child: _DarkTextField(
                                    ctrl: widget.portCtrl,
                                    label: 'Port',
                                    numeric: true),
                              ),
                            ],
                          ),
                        )
                      : const SizedBox.shrink(),
                ),
              ],
            ),
          ),

          // ── Privacy footer ───────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
            child: Text(
              'Uses Apple HealthKit (iOS) or Health Connect (Android).\n'
              'Only read access — your data stays on your device.',
              style: TextStyle(
                fontSize: 10,
                color: Colors.white.withOpacity(0.35),
                height: 1.6,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    ).animate().fadeIn(duration: 400.ms).slideY(begin: 0.05, end: 0);
  }
}

// ─── Connected card with live data ────────────────────────────────────────────

class _ConnectedCard extends StatelessWidget {
  final WatchState s;
  final AnimationController pulseCtrl;

  const _ConnectedCard({required this.s, required this.pulseCtrl});

  @override
  Widget build(BuildContext context) {
    final m = s.metrics!;
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF2D1B4E), Color(0xFF1A0F2E)],
        ),
        borderRadius: BorderRadius.circular(24),
      ),
      padding: const EdgeInsets.all(22),
      child: Column(
        children: [
          // Connected badge
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
            decoration: BoxDecoration(
              color: const Color(0xFF4ADE80).withOpacity(0.15),
              borderRadius: BorderRadius.circular(999),
              border: Border.all(
                  color: const Color(0xFF4ADE80).withOpacity(0.4)),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.circle, size: 8, color: Color(0xFF4ADE80)),
                SizedBox(width: 6),
                Text('Connected · Live',
                    style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF4ADE80))),
              ],
            ),
          ),

          const SizedBox(height: 20),

          // Watch face
          AnimatedBuilder(
            animation: pulseCtrl,
            builder: (_, __) => Transform.scale(
              scale: 0.97 + pulseCtrl.value * 0.04,
              child: Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const RadialGradient(
                    colors: [Color(0xFF3D2060), Color(0xFF1A0F2E)],
                  ),
                  border: Border.all(
                      color: const Color(0xFF4ADE80).withOpacity(0.5),
                      width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF4ADE80).withOpacity(0.2),
                      blurRadius: 20,
                      spreadRadius: 3,
                    ),
                  ],
                ),
                alignment: Alignment.center,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      '${m.heartRate}',
                      style: GoogleFonts.sourceCodePro(
                          fontSize: 28,
                          fontWeight: FontWeight.w800,
                          color: const Color(0xFFFF4F6A)),
                    ),
                    const Text('BPM',
                        style: TextStyle(
                            fontSize: 9,
                            color: Colors.white38,
                            letterSpacing: 1.5)),
                  ],
                ),
              ),
            ),
          ),

          const SizedBox(height: 16),

          // Quick stats row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _QuickStat('🚶', '${m.steps}', 'steps'),
              _QuickStat('🔥', '${m.calories}', 'kcal'),
              _QuickStat('🫀', '${m.spo2}%', 'SpO₂'),
              _QuickStat('🔋', '${m.battery}%', 'battery'),
            ],
          ),
        ],
      ),
    );
  }
}

class _QuickStat extends StatelessWidget {
  final String emoji;
  final String value;
  final String label;
  const _QuickStat(this.emoji, this.value, this.label);

  @override
  Widget build(BuildContext context) => Column(children: [
        Text(emoji, style: const TextStyle(fontSize: 16)),
        const SizedBox(height: 3),
        Text(value,
            style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: Colors.white)),
        Text(label,
            style: const TextStyle(fontSize: 9, color: Colors.white38)),
      ]);
}

// ─── Metrics Grid ─────────────────────────────────────────────────────────────

class _MetricsGrid extends StatelessWidget {
  final WatchState s;
  const _MetricsGrid({required this.s});

  @override
  Widget build(BuildContext context) {
    final m = s.metrics!;
    return GridView.count(
      crossAxisCount: 2,
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      childAspectRatio: 1.6,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      children: [
        _Tile('❤️', 'Heart Rate', '${m.heartRate}', 'BPM',
            const Color(0xFFFF4F6A), const Color(0xFF1E0A0E)),
        _Tile('🚶', 'Steps', _fmt(m.steps), 'today',
            const Color(0xFF4ADE80), const Color(0xFF091A0F)),
        _Tile('🔥', 'Calories', '${m.calories}', 'kcal',
            const Color(0xFFFB923C), const Color(0xFF1A0E06)),
        _Tile('🫀', 'SpO₂', '${m.spo2}', '%',
            const Color(0xFF60A5FA), const Color(0xFF060F1A)),
        _Tile('🧠', 'Stress', _stressLabel(m.stress), '${m.stress}/100',
            const Color(0xFFA78BFA), const Color(0xFF100A1A)),
        _Tile('🏃', 'Activity', _cap(m.activity), '',
            const Color(0xFFF59E0B), const Color(0xFF160F02)),
      ],
    );
  }

  String _fmt(int v) => v >= 1000 ? '${(v / 1000).toStringAsFixed(1)}k' : '$v';
  String _stressLabel(int v) => v < 30 ? 'Low' : v < 60 ? 'Med' : 'High';
  String _cap(String s) => s.isEmpty ? s : s[0].toUpperCase() + s.substring(1);
}

class _Tile extends StatelessWidget {
  final String emoji, label, value, unit;
  final Color color, bg;
  const _Tile(this.emoji, this.label, this.value, this.unit, this.color,
      this.bg);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(emoji, style: const TextStyle(fontSize: 16)),
              Text(label,
                  style:
                      const TextStyle(fontSize: 9, color: Colors.white38)),
            ],
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(value,
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      color: color)),
              if (unit.isNotEmpty) ...[
                const SizedBox(width: 2),
                Padding(
                  padding: const EdgeInsets.only(bottom: 2),
                  child: Text(unit,
                      style: const TextStyle(
                          fontSize: 9, color: Colors.white38)),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

// ─── HR Chart ─────────────────────────────────────────────────────────────────

class _HrChart extends StatelessWidget {
  final List<int> history;
  const _HrChart({required this.history});

  @override
  Widget build(BuildContext context) {
    final max = history.reduce(math.max).toDouble();
    final min = history.reduce(math.min).toDouble();
    final range = (max - min).clamp(10.0, double.infinity);

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0E0E12),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
            color: const Color(0xFFFF4F6A).withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('❤️  Heart Rate',
                  style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: Colors.white70)),
              Text('${history.last} BPM',
                  style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      color: Color(0xFFFF4F6A))),
            ],
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 48,
            child: CustomPaint(
              painter: _ChartPainter(
                  values: history, maxV: max, minV: min, range: range),
              size: Size.infinite,
            ),
          ),
        ],
      ),
    );
  }
}

class _ChartPainter extends CustomPainter {
  final List<int> values;
  final double maxV, minV, range;
  const _ChartPainter(
      {required this.values,
      required this.maxV,
      required this.minV,
      required this.range});

  @override
  void paint(Canvas canvas, Size size) {
    if (values.length < 2) return;
    final paint = Paint()
      ..color = const Color(0xFFFF4F6A)
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    final path = Path();
    final step = size.width / (values.length - 1);
    double y(int v) =>
        size.height - ((v - minV) / range) * size.height * 0.85;

    path.moveTo(0, y(values.first));
    for (var i = 1; i < values.length; i++) {
      final x = i * step;
      final px = (i - 1) * step;
      path.cubicTo(px + step * 0.5, y(values[i - 1]), x - step * 0.5,
          y(values[i]), x, y(values[i]));
    }
    canvas.drawPath(path, paint);

    // Live dot
    canvas.drawCircle(
        Offset(size.width, y(values.last)), 4,
        Paint()..color = const Color(0xFFFF4F6A));
  }

  @override
  bool shouldRepaint(_ChartPainter old) => old.values != values;
}

// ─── Auto-sync tile ───────────────────────────────────────────────────────────

class _SyncTile extends StatelessWidget {
  final bool autoSync;
  final VoidCallback onToggle;
  const _SyncTile({required this.autoSync, required this.onToggle});

  @override
  Widget build(BuildContext context) => Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF0E0E12),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
              color: autoSync
                  ? const Color(0xFF4ADE80).withOpacity(0.3)
                  : Colors.white12),
        ),
        child: Row(
          children: [
            const Text('🔄', style: TextStyle(fontSize: 16)),
            const SizedBox(width: 8),
            Expanded(
                child: Text('Auto-Sync',
                    style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: Colors.white70))),
            Switch.adaptive(
              value: autoSync,
              onChanged: (_) => onToggle(),
              activeColor: const Color(0xFF4ADE80),
              inactiveTrackColor: Colors.white12,
            ),
          ],
        ),
      );
}

// ─── Dark text field ──────────────────────────────────────────────────────────

class _DarkTextField extends StatelessWidget {
  final TextEditingController ctrl;
  final String label;
  final bool numeric;
  const _DarkTextField(
      {required this.ctrl, required this.label, this.numeric = false});

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: const TextStyle(fontSize: 9, color: Colors.white38)),
          const SizedBox(height: 4),
          TextField(
            controller: ctrl,
            keyboardType:
                numeric ? TextInputType.number : TextInputType.text,
            style: const TextStyle(fontSize: 12, color: Colors.white),
            decoration: InputDecoration(
              isDense: true,
              contentPadding: const EdgeInsets.symmetric(
                  horizontal: 10, vertical: 9),
              filled: true,
              fillColor: Colors.white.withOpacity(0.07),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide:
                      const BorderSide(color: Colors.white24)),
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide:
                      const BorderSide(color: Colors.white12)),
            ),
          ),
        ],
      );
}
