import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

import '../../../core/theme/app_theme.dart';
import '../providers/health_metrics_provider.dart';

// ─── Screen ──────────────────────────────────────────────────────────────────

class SmartWatchScreen extends ConsumerStatefulWidget {
  const SmartWatchScreen({super.key});

  @override
  ConsumerState<SmartWatchScreen> createState() => _SmartWatchScreenState();
}

class _SmartWatchScreenState extends ConsumerState<SmartWatchScreen> {
  @override
  void initState() {
    super.initState();
    // Auto-fetch if already authorised (e.g. returning to screen)
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final s = ref.read(healthMetricsProvider);
      if (s.isAuthorized && !s.hasAnyData) {
        ref.read(healthMetricsProvider.notifier).fetchAll();
      }
    });
  }

  // ─── helpers ─────────────────────────────────────────────────────────────

  String _fmtTime(DateTime? dt) {
    if (dt == null) return '—';
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inMinutes < 1) return 'just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    return DateFormat('MMM d, HH:mm').format(dt);
  }

  String _fmtDbl(double? v, {int decimals = 0}) {
    if (v == null) return '—';
    return v.toStringAsFixed(decimals);
  }

  Color _hrColor(double? bpm) {
    if (bpm == null) return AppColors.neutral400;
    if (bpm < 50 || bpm > 100) return AppColors.rose600;
    return AppColors.sage600;
  }

  Color _spo2Color(double? pct) {
    if (pct == null) return AppColors.neutral400;
    if (pct < 95) return AppColors.rose600;
    return AppColors.sage600;
  }

  Color _bpColor(double? sys) {
    if (sys == null) return AppColors.neutral400;
    if (sys > 140) return AppColors.rose600;
    if (sys > 120) return AppColors.warning;
    return AppColors.sage600;
  }

  String _hrZone(double? bpm) {
    if (bpm == null) return '';
    if (bpm < 50) return 'Low';
    if (bpm <= 100) return 'Normal';
    if (bpm <= 140) return 'Elevated';
    return 'High';
  }

  String _bpCategory(double? sys, double? dia) {
    if (sys == null || dia == null) return '';
    if (sys < 120 && dia < 80) return 'Normal';
    if (sys < 130 && dia < 80) return 'Elevated';
    if (sys < 140 || dia < 90) return 'Stage 1';
    return 'Stage 2';
  }

  Future<void> _connectDevice(HealthMetricsNotifier notifier) async {
    final connected = await notifier.requestPermissions();
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          connected
              ? 'Smartwatch health data connected.'
              : 'Could not connect health data. Check permissions and try again.',
        ),
      ),
    );
  }

  void _goBackToDashboard() {
    if (Navigator.of(context).canPop()) {
      Navigator.of(context).pop();
    } else {
      context.go('/dashboard');
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = ref.watch(healthMetricsProvider);
    final notifier = ref.read(healthMetricsProvider.notifier);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: RefreshIndicator(
          color: AppColors.plum700,
          onRefresh: notifier.fetchAll,
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(
                parent: BouncingScrollPhysics()),
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 8),
                _buildHeader(s, notifier),
                const SizedBox(height: 24),

                if (!s.isAuthorized) ...[
                  _buildConnectCard(s, notifier),
                ] else ...[
                  if (s.error != null) _buildErrorBanner(s.error!),
                  _buildSyncRow(s, notifier),
                  const SizedBox(height: 20),
                  _buildVitalGrid(s),
                  const SizedBox(height: 20),
                  _buildActivityRow(s),
                  const SizedBox(height: 20),
                  _buildBodyMetrics(s),
                  if (s.heartRateHistory.isNotEmpty) ...[
                    const SizedBox(height: 20),
                    _buildMiniChart(
                      title: 'Heart Rate (last readings)',
                      emoji: '❤️',
                      points: s.heartRateHistory
                          .map((p) => p.value)
                          .toList(),
                      color: AppColors.rose500,
                      unit: 'bpm',
                    ),
                  ],
                  if (s.spo2History.isNotEmpty) ...[
                    const SizedBox(height: 16),
                    _buildMiniChart(
                      title: 'Blood Oxygen (last readings)',
                      emoji: '💧',
                      points: s.spo2History
                          .map((p) => p.value)
                          .toList(),
                      color: AppColors.plum600,
                      unit: '%',
                    ),
                  ],
                ],
                const SizedBox(height: 100),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ─── widgets ─────────────────────────────────────────────────────────────

  Widget _buildHeader(HealthMetricsState s, HealthMetricsNotifier notifier) {
    return Row(
      children: [
        IconButton(
          onPressed: _goBackToDashboard,
          icon: const Icon(Icons.arrow_back_rounded),
          color: AppColors.plum900,
          tooltip: 'Back',
        ),
        const SizedBox(width: 4),
        Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: AppColors.plum100,
            borderRadius: BorderRadius.circular(16),
          ),
          alignment: Alignment.center,
          child: const Text('⌚', style: TextStyle(fontSize: 22)),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Health Metrics',
                style: GoogleFonts.playfairDisplay(
                  fontSize: 22,
                  fontWeight: FontWeight.w700,
                  color: AppColors.plum900,
                ),
              ),
              Text(
                s.isAuthorized
                    ? 'Synced from your device'
                    : 'Connect to get started',
                style: AppTextStyles.caption.copyWith(color: AppColors.neutral400),
              ),
            ],
          ),
        ),
        if (s.isLoading)
          const SizedBox(
            width: 20,
            height: 20,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              color: AppColors.plum700,
            ),
          ),
      ],
    ).animate().fadeIn(duration: 400.ms);
  }

  Widget _buildConnectCard(
      HealthMetricsState s, HealthMetricsNotifier notifier) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.plum900, AppColors.plum700],
        ),
        borderRadius: BorderRadius.circular(28),
      ),
      child: Column(
        children: [
          const Text('⌚', style: TextStyle(fontSize: 56))
              .animate()
              .slideY(begin: 0.2, end: 0, delay: 100.ms)
              .fadeIn(delay: 100.ms),
          const SizedBox(height: 20),
          Text(
            'Connect Health Data',
            style: GoogleFonts.playfairDisplay(
              fontSize: 24,
              fontWeight: FontWeight.w700,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            'Pull heart rate, blood pressure, SpO₂, steps,\nsleep, and more from your wearable device.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 13,
              color: Colors.white.withOpacity(0.7),
              height: 1.6,
            ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: s.isLoading ? null : () => _connectDevice(notifier),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: AppColors.plum900,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                elevation: 0,
              ),
              child: s.isLoading
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: AppColors.plum700),
                    )
                  : Text(
                      'Connect Smartwatch',
                      style: AppTextStyles.bodySemiBold
                          .copyWith(color: AppColors.plum900),
                    ),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'Uses Apple HealthKit (iOS) or Health Connect (Android).\nPair your watch there first. SensiaHealth only reads approved data.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 11,
              color: Colors.white.withOpacity(0.45),
              height: 1.5,
            ),
          ),
        ],
      ),
    ).animate().fadeIn(delay: 80.ms, duration: 400.ms).slideY(begin: 0.06, end: 0);
  }

  Widget _buildErrorBanner(String error) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.rose100,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.rose200),
      ),
      child: Row(
        children: [
          const Text('⚠️', style: TextStyle(fontSize: 18)),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              error,
              style: AppTextStyles.caption.copyWith(color: AppColors.rose700),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSyncRow(HealthMetricsState s, HealthMetricsNotifier notifier) {
    return Row(
      children: [
        Expanded(
          child: Text(
            s.lastSyncTime != null
                ? 'Last sync: ${_fmtTime(s.lastSyncTime)}'
                : 'Pull down to refresh',
            style: AppTextStyles.caption.copyWith(color: AppColors.neutral400),
          ),
        ),
        TextButton.icon(
          onPressed: s.isLoading ? null : notifier.fetchAll,
          icon: const Icon(Icons.refresh_rounded, size: 16),
          label: const Text('Sync'),
          style: TextButton.styleFrom(
            foregroundColor: AppColors.plum700,
            textStyle: AppTextStyles.caption
                .copyWith(fontWeight: FontWeight.w600),
          ),
        ),
      ],
    ).animate().fadeIn(delay: 100.ms);
  }

  Widget _buildVitalGrid(HealthMetricsState s) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Vital Signs', style: AppTextStyles.sectionTitle)
            .animate()
            .fadeIn(delay: 140.ms),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _VitalCard(
                emoji: '❤️',
                label: 'Heart Rate',
                value: s.heartRate != null
                    ? '${_fmtDbl(s.heartRate)} bpm'
                    : '—',
                sub: s.heartRate != null
                    ? _hrZone(s.heartRate)
                    : 'No data',
                time: _fmtTime(s.heartRateTime),
                statusColor: _hrColor(s.heartRate),
                bgColor: AppColors.rose100,
                delay: 160,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _VitalCard(
                emoji: '💧',
                label: 'Blood Oxygen',
                value: s.bloodOxygen != null
                    ? '${_fmtDbl(s.bloodOxygen, decimals: 1)}%'
                    : '—',
                sub: s.bloodOxygen != null
                    ? (s.bloodOxygen! >= 95 ? 'Normal' : 'Low')
                    : 'No data',
                time: _fmtTime(s.spo2Time),
                statusColor: _spo2Color(s.bloodOxygen),
                bgColor: AppColors.plum100,
                delay: 200,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _VitalCard(
                emoji: '🩸',
                label: 'Blood Pressure',
                value: (s.systolicBP != null && s.diastolicBP != null)
                    ? '${_fmtDbl(s.systolicBP)}/${_fmtDbl(s.diastolicBP)}'
                    : '—',
                sub: (s.systolicBP != null && s.diastolicBP != null)
                    ? _bpCategory(s.systolicBP, s.diastolicBP)
                    : 'No data',
                time: _fmtTime(s.bpTime),
                statusColor: _bpColor(s.systolicBP),
                bgColor: AppColors.rose50,
                delay: 240,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _VitalCard(
                emoji: '🌡️',
                label: 'Body Temp',
                value: s.bodyTemperature != null
                    ? '${_fmtDbl(s.bodyTemperature, decimals: 1)}°C'
                    : '—',
                sub: s.bodyTemperature != null
                    ? (s.bodyTemperature! > 37.5 ? 'Elevated' : 'Normal')
                    : 'No data',
                time: _fmtTime(s.tempTime),
                statusColor: s.bodyTemperature != null &&
                        s.bodyTemperature! > 37.5
                    ? AppColors.rose600
                    : AppColors.sage600,
                bgColor: AppColors.sage100,
                delay: 280,
              ),
            ),
          ],
        ),
        if (s.respiratoryRate != null) ...[
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: cardDecoration(),
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: AppColors.sage100,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  alignment: Alignment.center,
                  child: const Text('🫁', style: TextStyle(fontSize: 20)),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Respiratory Rate',
                          style: AppTextStyles.caption
                              .copyWith(color: AppColors.neutral500)),
                      Text(
                        '${_fmtDbl(s.respiratoryRate, decimals: 0)} breaths/min',
                        style: AppTextStyles.bodySemiBold,
                      ),
                    ],
                  ),
                ),
                Container(
                  width: 8,
                  height: 8,
                  decoration: const BoxDecoration(
                    color: AppColors.sage600,
                    shape: BoxShape.circle,
                  ),
                ),
              ],
            ),
          ).animate().fadeIn(delay: 310.ms, duration: 350.ms),
        ],
      ],
    );
  }

  Widget _buildActivityRow(HealthMetricsState s) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Activity Today', style: AppTextStyles.sectionTitle)
            .animate()
            .fadeIn(delay: 320.ms),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _ActivityTile(
                emoji: '🚶',
                label: 'Steps',
                value: s.steps != null
                    ? NumberFormat('#,###').format(s.steps)
                    : '—',
                sub: s.steps != null
                    ? '${(s.steps! / 10000 * 100).toStringAsFixed(0)}% of goal'
                    : 'No data',
                delay: 340,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _ActivityTile(
                emoji: '🔥',
                label: 'Calories',
                value: s.activeCalories != null
                    ? '${_fmtDbl(s.activeCalories, decimals: 0)} kcal'
                    : '—',
                sub: 'Active calories',
                delay: 380,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildBodyMetrics(HealthMetricsState s) {
    if (s.weight == null && s.height == null) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Body Metrics', style: AppTextStyles.sectionTitle)
            .animate()
            .fadeIn(delay: 400.ms),
        const SizedBox(height: 12),
        Row(
          children: [
            if (s.weight != null)
              Expanded(
                child: _ActivityTile(
                  emoji: '⚖️',
                  label: 'Weight',
                  value: '${_fmtDbl(s.weight, decimals: 1)} kg',
                  sub: 'Last recorded',
                  delay: 420,
                ),
              ),
            if (s.weight != null && s.height != null) const SizedBox(width: 12),
            if (s.height != null)
              Expanded(
                child: _ActivityTile(
                  emoji: '📏',
                  label: 'Height',
                  value: '${_fmtDbl(s.height, decimals: 0)} cm',
                  sub: 'Last recorded',
                  delay: 460,
                ),
              ),
            // BMI if both available
            if (s.weight != null && s.height != null) ...[
              const SizedBox(width: 12),
              Expanded(
                child: _ActivityTile(
                  emoji: '🧮',
                  label: 'BMI',
                  value: _fmtDbl(
                    s.weight! / ((s.height! / 100) * (s.height! / 100)),
                    decimals: 1,
                  ),
                  sub: _bmiCategory(s.weight!, s.height!),
                  delay: 500,
                ),
              ),
            ],
          ],
        ),
      ],
    );
  }

  String _bmiCategory(double weightKg, double heightCm) {
    final bmi = weightKg / ((heightCm / 100) * (heightCm / 100));
    if (bmi < 18.5) return 'Underweight';
    if (bmi < 25) return 'Normal';
    if (bmi < 30) return 'Overweight';
    return 'Obese';
  }

  Widget _buildMiniChart({
    required String title,
    required String emoji,
    required List<double> points,
    required Color color,
    required String unit,
  }) {
    if (points.isEmpty) return const SizedBox.shrink();

    final minV = points.reduce((a, b) => a < b ? a : b);
    final maxV = points.reduce((a, b) => a > b ? a : b);
    final range = (maxV - minV).clamp(1.0, double.infinity);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: cardDecoration(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(emoji, style: const TextStyle(fontSize: 18)),
              const SizedBox(width: 8),
              Text(title, style: AppTextStyles.bodySemiBold),
            ],
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 60,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: points.map((v) {
                final pct = ((v - minV) / range).clamp(0.05, 1.0);
                return Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 2),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          v.toStringAsFixed(0),
                          style: TextStyle(
                              fontSize: 8, color: AppColors.neutral500),
                        ),
                        const SizedBox(height: 2),
                        Container(
                          height: 48 * pct,
                          decoration: BoxDecoration(
                            color: color.withOpacity(0.7),
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Min ${minV.toStringAsFixed(0)} · Avg ${(points.reduce((a, b) => a + b) / points.length).toStringAsFixed(0)} · Max ${maxV.toStringAsFixed(0)} $unit',
            style: AppTextStyles.caption.copyWith(color: AppColors.neutral400),
          ),
        ],
      ),
    ).animate().fadeIn(delay: 520.ms, duration: 350.ms);
  }
}

// ─── Vital card ───────────────────────────────────────────────────────────────

class _VitalCard extends StatelessWidget {
  final String emoji;
  final String label;
  final String value;
  final String sub;
  final String time;
  final Color statusColor;
  final Color bgColor;
  final int delay;

  const _VitalCard({
    required this.emoji,
    required this.label,
    required this.value,
    required this.sub,
    required this.time,
    required this.statusColor,
    required this.bgColor,
    required this.delay,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: cardDecoration(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: bgColor,
                  borderRadius: BorderRadius.circular(12),
                ),
                alignment: Alignment.center,
                child: Text(emoji, style: const TextStyle(fontSize: 18)),
              ),
              const Spacer(),
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: statusColor,
                  shape: BoxShape.circle,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            value,
            style: AppTextStyles.bodySemiBold.copyWith(fontSize: 18),
          ),
          Text(label,
              style:
                  AppTextStyles.caption.copyWith(color: AppColors.neutral500)),
          const SizedBox(height: 4),
          Text(
            sub,
            style: AppTextStyles.caption.copyWith(
              color: statusColor,
              fontWeight: FontWeight.w600,
              fontSize: 10,
            ),
          ),
          Text(
            time,
            style:
                AppTextStyles.caption.copyWith(color: AppColors.neutral400, fontSize: 10),
          ),
        ],
      ),
    )
        .animate()
        .fadeIn(delay: Duration(milliseconds: delay), duration: 350.ms)
        .slideY(begin: 0.05, end: 0);
  }
}

// ─── Activity tile ────────────────────────────────────────────────────────────

class _ActivityTile extends StatelessWidget {
  final String emoji;
  final String label;
  final String value;
  final String sub;
  final int delay;

  const _ActivityTile({
    required this.emoji,
    required this.label,
    required this.value,
    required this.sub,
    required this.delay,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: cardDecoration(),
      child: Row(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 22)),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(value, style: AppTextStyles.bodySemiBold),
                Text(label,
                    style: AppTextStyles.caption
                        .copyWith(color: AppColors.neutral500)),
                Text(sub,
                    style: AppTextStyles.caption
                        .copyWith(color: AppColors.neutral400, fontSize: 10)),
              ],
            ),
          ),
        ],
      ),
    )
        .animate()
        .fadeIn(delay: Duration(milliseconds: delay), duration: 350.ms)
        .slideX(begin: 0.04, end: 0);
  }
}
